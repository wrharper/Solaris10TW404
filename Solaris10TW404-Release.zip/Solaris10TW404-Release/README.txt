# Solaris 10 TalesWeaver Setup & IP Converter Tool

This release contains:
1. Complete Solaris 10 TalesWeaver Server setup documentation (README.md)
2. IPConverter - A Windows WPF application to convert IP addresses to decimal format

## IPConverter Tool

The IPConverter application helps convert IP addresses to decimal format, which is required
for the TalesWeaver server configuration.

### Using IPConverter:
1. Extract the files to a folder on your Windows machine
2. Run IPConverter.exe
3. Enter an IP address (e.g., 192.168.1.200)
4. Click "Convert" to get the decimal representation
5. Use the "Copy to Clipboard" button to easily copy the result

### Building from Source:
The source code is included in this repository. To build:
1. Install .NET 10.0 SDK or later
2. Open IPConverter.sln in Visual Studio 2022 or later
3. Build the solution in Release mode

## Documentation

See README.md for the complete Solaris 10 TalesWeaver Server setup guide.

## Version Information

This release includes the IP conversion formula fix to ensure correct decimal conversion.

Formula: For IP a.b.c.d, the decimal value is (d × 256³) + (c × 256²) + (b × 256) + a

## License

See repository for license information.
